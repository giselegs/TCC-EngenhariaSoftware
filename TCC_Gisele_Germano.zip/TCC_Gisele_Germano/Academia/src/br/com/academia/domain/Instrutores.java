package br.com.academia.domain;

public class Instrutores {
	private int idInstrutor;
	private String nomeInstrutor;
	private String cpfInstrutor;
	private String rgInstrutor;
	private String atividadeInstrutor;
	public int getIdInstrutor() {
		return idInstrutor;
	}
	public void setIdInstrutor(int idInstrutor) {
		this.idInstrutor = idInstrutor;
	}
	public String getNomeInstrutor() {
		return nomeInstrutor;
	}
	public void setNomeInstrutor(String nomeInstrutor) {
		this.nomeInstrutor = nomeInstrutor;
	}
	public String getCpfInstrutor() {
		return cpfInstrutor;
	}
	public void setCpfInstrutor(String cpfInstrutor) {
		this.cpfInstrutor = cpfInstrutor;
	}
	public String getRgInstrutor() {
		return rgInstrutor;
	}
	public void setRgInstrutor(String rgInstrutor) {
		this.rgInstrutor = rgInstrutor;
	}
	public String getAtividadeInstrutor() {
		return atividadeInstrutor;
	}
	public void setAtividadeInstrutor(String atividadeInstrutor) {
		this.atividadeInstrutor = atividadeInstrutor;
	}
	@Override
	public String toString() {
		String saida = idInstrutor + " - " + nomeInstrutor + " - " + rgInstrutor + " - " + cpfInstrutor + " - " + atividadeInstrutor ;
		return saida;
	}
	

}
