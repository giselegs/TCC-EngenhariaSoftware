package br.com.academia.domain;

public class PagamentosPendentes {
	private int idPagamento;
	private String vencimento1;
	private String vencimento2;
	private String vencimento3;
	private String vencimento4;
	private String vencimento5;
	private String vencimento6;
	private String vencimento7;
	private String vencimento8;
	private String vencimento9;
	private String vencimento10;
	private String vencimento11;
	private String vencimento12;
	private Clientes clientes = new Clientes();
	
	
	
	public int getIdPagamento() {
		return idPagamento;
	}
	public void setIdPagamento(int idPagamento) {
		this.idPagamento = idPagamento;
	}
	public Clientes getClientes() {
		return clientes;
	}
	public void setClientes(Clientes clientes) {
		this.clientes = clientes;
	}
	public String getVencimento1() {
		return vencimento1;
	}
	public void setVencimento1(String vencimento1) {
		this.vencimento1 = vencimento1;
	}
	public String getVencimento2() {
		return vencimento2;
	}
	public void setVencimento2(String vencimento2) {
		this.vencimento2 = vencimento2;
	}
	public String getVencimento3() {
		return vencimento3;
	}
	public void setVencimento3(String vencimento3) {
		this.vencimento3 = vencimento3;
	}
	public String getVencimento4() {
		return vencimento4;
	}
	public void setVencimento4(String vencimento4) {
		this.vencimento4 = vencimento4;
	}
	public String getVencimento5() {
		return vencimento5;
	}
	public void setVencimento5(String vencimento5) {
		this.vencimento5 = vencimento5;
	}
	public String getVencimento6() {
		return vencimento6;
	}
	public void setVencimento6(String vencimento6) {
		this.vencimento6 = vencimento6;
	}
	public String getVencimento7() {
		return vencimento7;
	}
	public void setVencimento7(String vencimento7) {
		this.vencimento7 = vencimento7;
	}
	public String getVencimento8() {
		return vencimento8;
	}
	public void setVencimento8(String vencimento8) {
		this.vencimento8 = vencimento8;
	}
	public String getVencimento9() {
		return vencimento9;
	}
	public void setVencimento9(String vencimento9) {
		this.vencimento9 = vencimento9;
	}
	public String getVencimento10() {
		return vencimento10;
	}
	public void setVencimento10(String vencimento10) {
		this.vencimento10 = vencimento10;
	}
	public String getVencimento11() {
		return vencimento11;
	}
	public void setVencimento11(String vencimento11) {
		this.vencimento11 = vencimento11;
	}
	public String getVencimento12() {
		return vencimento12;
	}
	public void setVencimento12(String vencimento12) {
		this.vencimento12 = vencimento12;
	}
	
	
	

}
