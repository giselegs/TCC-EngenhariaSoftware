package br.com.academia.domain;

public class Aulas {
	private int idAula;
	private String nomeAula;
	private String horarioInicio;
	private String horarioFim;
	private String sala;
	private String diasSemana;
	private Instrutores instrutores = new Instrutores();
	
		
	
	public Instrutores getInstrutores() {
		return instrutores;
	}
	public void setInstrutores(Instrutores instrutores) {
		this.instrutores = instrutores;
	}
	public int getIdAula() {
		return idAula;
	}
	public void setIdAula(int idAula) {
		this.idAula = idAula;
	}
	public String getNomeAula() {
		return nomeAula;
	}
	public void setNomeAula(String nomeAula) {
		this.nomeAula = nomeAula;
	}
	public String getHorarioInicio() {
		return horarioInicio;
	}
	public void setHorarioInicio(String horarioInicio) {
		this.horarioInicio = horarioInicio;
	}
	public String getHorarioFim() {
		return horarioFim;
	}
	public void setHorarioFim(String horarioFim) {
		this.horarioFim = horarioFim;
	}
	public String getSala() {
		return sala;
	}
	public void setSala(String sala) {
		this.sala = sala;
	}
	public String getDiasSemana() {
		return diasSemana;
	}
	public void setDiasSemana(String diasSemana) {
		this.diasSemana = diasSemana;
	}
	

}
