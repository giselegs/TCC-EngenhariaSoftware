package br.com.academia.domain;

public class Pagamentos {
	private int idPagamento;

	public int getIdPagamento() {
		return idPagamento;
	}

	public void setIdPagamento(int idPagamento) {
		this.idPagamento = idPagamento;
	}
	
	

}
