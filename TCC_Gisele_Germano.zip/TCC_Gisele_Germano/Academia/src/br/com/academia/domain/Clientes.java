package br.com.academia.domain;

public class Clientes {
	private int idCliente;
	private String nomeCliente;
	private String rgCliente;
	private String cpfCliente;
	private String logradouroCliente;
	private int numeroCliente;
	private String bairroCliente;
	private String cidadeCliente;
	private String ufCliente;
	private String planoCliente;
	private int melhorDiaPagamento;
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public String getNomeCliente() {
		return nomeCliente;
	}
	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}
	public String getRgCliente() {
		return rgCliente;
	}
	public void setRgCliente(String rgCliente) {
		this.rgCliente = rgCliente;
	}
	public String getCpfCliente() {
		return cpfCliente;
	}
	public void setCpfCliente(String cpfCliente) {
		this.cpfCliente = cpfCliente;
	}
	public String getLogradouroCliente() {
		return logradouroCliente;
	}
	public void setLogradouroCliente(String logradouroCliente) {
		this.logradouroCliente = logradouroCliente;
	}
	public int getNumeroCliente() {
		return numeroCliente;
	}
	public void setNumeroCliente(int numeroCliente) {
		this.numeroCliente = numeroCliente;
	}
	public String getBairroCliente() {
		return bairroCliente;
	}
	public void setBairroCliente(String bairroCliente) {
		this.bairroCliente = bairroCliente;
	}
	public String getCidadeCliente() {
		return cidadeCliente;
	}
	public void setCidadeCliente(String cidadeCliente) {
		this.cidadeCliente = cidadeCliente;
	}
	public String getUfCliente() {
		return ufCliente;
	}
	public void setUfCliente(String ufCliente) {
		this.ufCliente = ufCliente;
	}
	public String getPlanoCliente() {
		return planoCliente;
	}
	public void setPlanoCliente(String planoCliente) {
		this.planoCliente = planoCliente;
	}
	public int getMelhorDiaPagamento() {
		return melhorDiaPagamento;
	}
	public void setMelhorDiaPagamento(int melhorDiaPagamento) {
		this.melhorDiaPagamento = melhorDiaPagamento;
	}
	
	@Override
	public String toString() {
		String saida = idCliente + " - " + nomeCliente + " - " + rgCliente + " - " + cpfCliente + " - " + logradouroCliente + " - " + numeroCliente + " - " + bairroCliente + " - " + cidadeCliente + " - " + ufCliente + " - " + planoCliente + " - " + melhorDiaPagamento;
		return saida;
	}
	
	
	
	

}
