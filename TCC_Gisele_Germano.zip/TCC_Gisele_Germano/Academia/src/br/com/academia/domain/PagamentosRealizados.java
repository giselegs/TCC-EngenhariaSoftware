package br.com.academia.domain;

public class PagamentosRealizados {
	private Pagamentos pagamentos;
	private String pagamento1;
	private String pagamento2;
	private String pagamento3;
	private String pagamento4;
	private String pagamento5;
	private String pagamento6;
	private String pagamento7;
	private String pagamento8;
	private String pagamento9;
	private String pagamento10;
	private String pagamento11;
	private String pagamento12;
	
	
	
	
	
	public Pagamentos getPagamentos() {
		return pagamentos;
	}
	public void setPagamentos(Pagamentos pagamentos) {
		this.pagamentos = pagamentos;
	}
	public String getPagamento1() {
		return pagamento1;
	}
	public void setPagamento1(String pagamento1) {
		this.pagamento1 = pagamento1;
	}
	public String getPagamento2() {
		return pagamento2;
	}
	public void setPagamento2(String pagamento2) {
		this.pagamento2 = pagamento2;
	}
	public String getPagamento3() {
		return pagamento3;
	}
	public void setPagamento3(String pagamento3) {
		this.pagamento3 = pagamento3;
	}
	public String getPagamento4() {
		return pagamento4;
	}
	public void setPagamento4(String pagamento4) {
		this.pagamento4 = pagamento4;
	}
	public String getPagamento5() {
		return pagamento5;
	}
	public void setPagamento5(String pagamento5) {
		this.pagamento5 = pagamento5;
	}
	public String getPagamento6() {
		return pagamento6;
	}
	public void setPagamento6(String pagamento6) {
		this.pagamento6 = pagamento6;
	}
	public String getPagamento7() {
		return pagamento7;
	}
	public void setPagamento7(String pagamento7) {
		this.pagamento7 = pagamento7;
	}
	public String getPagamento8() {
		return pagamento8;
	}
	public void setPagamento8(String pagamento8) {
		this.pagamento8 = pagamento8;
	}
	public String getPagamento9() {
		return pagamento9;
	}
	public void setPagamento9(String pagamento9) {
		this.pagamento9 = pagamento9;
	}
	public String getPagamento10() {
		return pagamento10;
	}
	public void setPagamento10(String pagamento10) {
		this.pagamento10 = pagamento10;
	}
	public String getPagamento11() {
		return pagamento11;
	}
	public void setPagamento11(String pagamento11) {
		this.pagamento11 = pagamento11;
	}
	public String getPagamento12() {
		return pagamento12;
	}
	public void setPagamento12(String pagamento12) {
		this.pagamento12 = pagamento12;
	}
	
	

}
