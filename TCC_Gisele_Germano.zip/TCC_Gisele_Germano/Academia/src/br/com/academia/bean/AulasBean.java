package br.com.academia.bean;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import br.com.academia.DAO.AulasDAO;
import br.com.academia.DAO.InstrutoresDAO;
import br.com.academia.domain.Aulas;
import br.com.academia.domain.Instrutores;
import br.com.academia.util.JSFUtil;

@ManagedBean(name = "MBAulas")
@ViewScoped
public class AulasBean {
	
	private Aulas aulas;
	private ArrayList<Aulas> itens;
	private ArrayList<Aulas> itensFiltrados;
	private ArrayList<Instrutores> comboInstrutores;
	
	public Aulas getAulas() {
		return aulas;
	}

	public void setAulas(Aulas aulas) {
		this.aulas = aulas;
	}

	
	public ArrayList<Aulas> getItens() {
		return itens;
	}
	
	public void setItens(ArrayList<Aulas> itens) {
		this.itens = itens;
	}
	
	public ArrayList<Aulas> getItensFiltrados() {
		return itensFiltrados;
	}
	
	public void setItensFiltrados(ArrayList<Aulas> itensFiltrados) {
		this.itensFiltrados = itensFiltrados;
	}
	
	public ArrayList<Instrutores> getComboInstrutores() {
		return comboInstrutores;
	}

	public void setComboInstrutores(ArrayList<Instrutores> comboInstrutores) {
		this.comboInstrutores = comboInstrutores;
	}

	@PostConstruct
	public void prepararPesquisa(){
		try {
			AulasDAO adao = new AulasDAO();
			itens = adao.listar();		
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void prepararNovo(){
		
		try {
			aulas = new Aulas();
			
			InstrutoresDAO dao = new InstrutoresDAO();
			comboInstrutores = dao.listar();
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public void novo(){
		try {
			AulasDAO adao = new AulasDAO();
			adao.salvar(aulas);
			
			itens = adao.listar();		
			JSFUtil.adicionarMensagemSucesso("Aula salva com sucesso!");
			
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void excluir(){
		try {
			AulasDAO adao = new AulasDAO();
			adao.excluir(aulas);
			
			itens = adao.listar();
						
			JSFUtil.adicionarMensagemSucesso("Aula exclu�da com sucesso!");
			
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	public void editar(){
		try {
			AulasDAO adao = new AulasDAO();
			adao.editar(aulas);
			
			itens = adao.listar();
						
			JSFUtil.adicionarMensagemSucesso("Aula editada com sucesso!");
			
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
		
	}

	
	
}
