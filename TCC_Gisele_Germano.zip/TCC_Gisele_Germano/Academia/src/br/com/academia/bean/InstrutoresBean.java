package br.com.academia.bean;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import br.com.academia.DAO.InstrutoresDAO;
import br.com.academia.domain.Instrutores;
import br.com.academia.util.JSFUtil;

@ManagedBean(name = "MBInstrutores")
@ViewScoped
public class InstrutoresBean {
	
	private Instrutores instrutores;
	private ArrayList<Instrutores> itens;
	private ArrayList<Instrutores> itensFiltrados;
	
	public Instrutores getInstrutores() {
		return instrutores;
	}

	public void setInstrutores(Instrutores instrutores) {
		this.instrutores = instrutores;
	}

	
	public ArrayList<Instrutores> getItens() {
		return itens;
	}
	
	public void setItens(ArrayList<Instrutores> itens) {
		this.itens = itens;
	}
	
	public ArrayList<Instrutores> getItensFiltrados() {
		return itensFiltrados;
	}
	
	public void setItensFiltrados(ArrayList<Instrutores> itensFiltrados) {
		this.itensFiltrados = itensFiltrados;
	}
	

	@PostConstruct
	public void prepararPesquisa(){
		try {
			InstrutoresDAO idao = new InstrutoresDAO();
			itens = idao.listar();		
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void prepararNovo(){
		instrutores = new Instrutores();
	}
	
	
	public void novo(){
		try {
			InstrutoresDAO idao = new InstrutoresDAO();
			idao.salvar(instrutores);
			
			itens = idao.listar();		
			JSFUtil.adicionarMensagemSucesso("Instrutor salvo com sucesso!");
			
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void excluir(){
		try {
			InstrutoresDAO idao = new InstrutoresDAO();
			idao.excluir(instrutores);
			
			itens = idao.listar();
						
			JSFUtil.adicionarMensagemSucesso("Instrutor exclu�do com sucesso!");
			
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro("N�o � poss�vel excluir instrutores que est�o associados a aulas");
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro("N�o � poss�vel excluir instrutores que est�o associados a aulas");
			e.printStackTrace();
		}
		
	}
	
	public void editar(){
		try {
			InstrutoresDAO idao = new InstrutoresDAO();
			idao.editar(instrutores);
			
			itens = idao.listar();
						
			JSFUtil.adicionarMensagemSucesso("Instrutor editado com sucesso!");
			
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
		
	}

	
	
}

