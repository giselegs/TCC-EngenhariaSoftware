package br.com.academia.bean;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import br.com.academia.DAO.PagamentosPendentesDAO;
import br.com.academia.domain.Clientes;
import br.com.academia.domain.PagamentosPendentes;
import br.com.academia.DAO.ClientesDAO;
import br.com.academia.util.JSFUtil;

@ManagedBean(name = "MBPagPendentes")
@ViewScoped
public class PagamentosPendentesBean {
	
	private PagamentosPendentes pagamentosPendentes;
	private ArrayList<PagamentosPendentes> itens;
	private ArrayList<PagamentosPendentes> itensFiltrados;
	
	
	public PagamentosPendentes getPagamentosPendentes() {
		return pagamentosPendentes;
	}

	public void setPagamentosPendentes(PagamentosPendentes pagamentosPendentes) {
		this.pagamentosPendentes = pagamentosPendentes;
	}

	public ArrayList<PagamentosPendentes> getItens() {
		return itens;
	}

	public void setItens(ArrayList<PagamentosPendentes> itens) {
		this.itens = itens;
	}

	public ArrayList<PagamentosPendentes> getItensFiltrados() {
		return itensFiltrados;
	}

	public void setItensFiltrados(ArrayList<PagamentosPendentes> itensFiltrados) {
		this.itensFiltrados = itensFiltrados;
	}

	

	@PostConstruct
	public void prepararPesquisa(){
		try {
			PagamentosPendentesDAO ppdao = new PagamentosPendentesDAO();
			itens = ppdao.listar();		
		} catch (ClassNotFoundException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		} catch (SQLException e) {
			JSFUtil.adicionarMensagemErro(e.getMessage());
			e.printStackTrace();
		}
	}
	public String convertString(Date data){
		
		String dataConvertida =null;
				
		SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy");
		dataConvertida = f.format(data);
		
		return dataConvertida;
		
	}
	
		
}

