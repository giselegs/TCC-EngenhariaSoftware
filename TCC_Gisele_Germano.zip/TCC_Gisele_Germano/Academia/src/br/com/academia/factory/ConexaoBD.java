package br.com.academia.factory;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConexaoBD {
	public static final String USUARIO = "root";
	public static final String SENHA = "giselegs";
	public static final String URL = "jdbc:mysql://localhost:3306/academia?characterEncoding=utf8";
	
	public static Connection conectar() throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
		return conexao;
	}
	
public static void main(String[] args) throws ClassNotFoundException {
	try{
	Connection conexao = ConexaoBD.conectar();
	System.out.println("Conectado com sucesso!");
	}
	
	catch(SQLException ex){
		ex.printStackTrace();
		System.out.println("Conex�o falhou!");
	}
}
}
