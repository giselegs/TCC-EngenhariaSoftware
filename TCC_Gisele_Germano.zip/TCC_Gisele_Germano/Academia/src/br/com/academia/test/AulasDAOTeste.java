package br.com.academia.test;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Ignore;
import org.junit.Test;

import br.com.academia.DAO.AulasDAO;
import br.com.academia.domain.Aulas;
import br.com.academia.domain.Instrutores;

public class AulasDAOTeste {
	
	@Test
	@Ignore
	public void salvar() throws SQLException, ClassNotFoundException{
		Aulas a1 = new Aulas();
		a1.setNomeAula("Zumba");
		a1.setHorarioInicio("10:20");
		a1.setHorarioFim("11:00");
		a1.setSala("2");
		a1.setDiasSemana("Segunda-feira");
				
		Instrutores i = new Instrutores();
		i.setIdInstrutor(4);
		
		a1.setInstrutores(i);
	
		AulasDAO adao = new AulasDAO();
				
			adao.salvar(a1);
		
	}
	
	@Test
	public void listar() throws SQLException, ClassNotFoundException{
		AulasDAO adao = new AulasDAO();
		
		ArrayList<Aulas> lista = adao.listar();
		
		for(Aulas a : lista){
			System.out.println("C�digo:" + a.getIdAula());
			System.out.println("Aula:" + a.getNomeAula());
			System.out.println("In�cio:" + a.getHorarioInicio());
			System.out.println("Fim:" + a.getHorarioFim());
			System.out.println("Sala:" + a.getSala());
			System.out.println("Dias da semana:" + a.getDiasSemana());
			System.out.println("Instrutor:" + a.getInstrutores().getNomeInstrutor());
			System.out.println(" ");
		}
	}
	
	
}


