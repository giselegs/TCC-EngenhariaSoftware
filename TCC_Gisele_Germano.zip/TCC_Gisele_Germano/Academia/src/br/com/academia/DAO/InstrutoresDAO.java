package br.com.academia.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import br.com.academia.domain.Instrutores;
import br.com.academia.factory.ConexaoBD;

public class InstrutoresDAO {
	public void salvar(Instrutores i) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO instrutores");
		sql.append("(nomeInstrutor,");
		sql.append("cpfInstrutor,");
		sql.append("rgInstrutor,");
		sql.append("atividadeInstrutor)");
		sql.append("VALUES (?,?,?,?)");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setString(1, i.getNomeInstrutor());
		comando.setString(2, i.getCpfInstrutor());
		comando.setString(3, i.getRgInstrutor());
		comando.setString(4, i.getAtividadeInstrutor());
		comando.executeUpdate();	
	}
	
	public void excluir (Instrutores i) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE FROM instrutores  ");
		sql.append("WHERE idInstrutor = ? ");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setInt(1, i.getIdInstrutor());
		comando.executeUpdate();
	}
	
	public void editar (Instrutores i) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("UPDATE instrutores ");
		sql.append("SET atividadeInstrutor = ? ");
		sql.append("WHERE idInstrutor = ?");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setString(1, i.getAtividadeInstrutor());
		comando.setInt(2, i.getIdInstrutor());
		comando.executeUpdate();
	}
	
	
	public Instrutores buscaPorCodigo(Instrutores i) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM instrutores ");
	    sql.append("WHERE idInstrutor = ?");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setInt(1, i.getIdInstrutor());
		
		ResultSet resultado = comando.executeQuery();
		
		Instrutores retorno = null;
		
		if(resultado.next()){
			retorno = new Instrutores();
			retorno.setIdInstrutor(resultado.getInt("idInstrutor"));
			retorno.setNomeInstrutor(resultado.getString("nomeInstrutor"));
			retorno.setRgInstrutor(resultado.getString("rgInstrutor"));
			retorno.setCpfInstrutor(resultado.getString("cpfInstrutor"));
			retorno.setAtividadeInstrutor(resultado.getString("atividadeInstrutor"));
			
		}
		
		return retorno;
		
	}public ArrayList<Instrutores> buscaPorNome(Instrutores i) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM instrutores ");
		sql.append("WHERE nomeInstrtutor LIKE  ?");
		sql.append("ORDER BY nomeInstrutor ASC");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		
		comando.setString(1, "%" + i.getNomeInstrutor() + "%");
		
		ResultSet resultado = comando.executeQuery();
		
		ArrayList<Instrutores> lista = new ArrayList<Instrutores>();
		
		while(resultado.next()){
			Instrutores item = new Instrutores();
			item.setIdInstrutor(resultado.getInt("idInstrutor"));
			item.setNomeInstrutor(resultado.getString("nomeInstrutor"));
			item.setCpfInstrutor(resultado.getString("cpfInstrutor"));
			item.setRgInstrutor(resultado.getString("rgInstrutor"));
			item.setAtividadeInstrutor(resultado.getString("atividadeInstrutor"));
						
			lista.add(item);
		}
		return lista;
		
	}
	
	
	public ArrayList <Instrutores> listar() throws SQLException, ClassNotFoundException {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM instrutores ");
	    sql.append("ORDER BY idInstrutor ASC");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		
		
		ResultSet resultado = comando.executeQuery();
		
		ArrayList<Instrutores> lista = new ArrayList<Instrutores>();
		
		while(resultado.next()){
			Instrutores i = new Instrutores();
			i.setIdInstrutor(resultado.getInt("idInstrutor"));
			i.setNomeInstrutor(resultado.getString("nomeInstrutor"));
			i.setCpfInstrutor(resultado.getString("cpfInstrutor"));
			i.setRgInstrutor(resultado.getString("rgInstrutor"));
			i.setAtividadeInstrutor(resultado.getString("atividadeInstrutor"));
			
			lista.add(i);
		}
		return lista;
	}
	
	public static void main(String[] args) {
		/*Instrutores i1 = new Instrutores();
		i1.setNomeInstrutor("Renata Mariana das Neves");
		i1.setCpfInstrutor("05723857061");
		i1.setRgInstrutor("297576616");
		i1.setAtividadeInstrutor("Aulas em grupo");
		
		
		Instrutores i2 = new Instrutores();
		i2.setNomeInstrutor("Amanda Renata M�rcia Martins");
		i2.setCpfInstrutor("17388585702");
		i2.setRgInstrutor("508747831");
		i2.setAtividadeInstrutor("Muscula��o");
		
		
		InstrutoresDAO idao = new InstrutoresDAO();
		try {
			idao.salvar(i1);
			idao.salvar(i2);
			System.out.println("Salvo com sucesso!");
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao salvar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao salvar 2!");
			e.printStackTrace();
		}*/
		
	}

}

