package br.com.academia.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.academia.domain.Aulas;
import br.com.academia.domain.Clientes;
import br.com.academia.domain.PagamentosPendentes;
import br.com.academia.factory.ConexaoBD;

public class PagamentosPendentesDAO {
	
	public ArrayList <PagamentosPendentes> listar() throws SQLException, ClassNotFoundException {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT pp.idPagamento, pp.vencimento1, pp.vencimento2,  pp.fk_clientes, c.nomeCliente ");
		sql.append("FROM pagamentosPendentes pp ");
	    sql.append("INNER JOIN clientes c on c.idCliente = pp.fk_clientes ");
	    sql.append("WHERE pp.vencimento1 <= CURDATE()");
		
Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		
		
		ResultSet resultado = comando.executeQuery();
		
		ArrayList<PagamentosPendentes> lista = new ArrayList<PagamentosPendentes>();
		
		while(resultado.next()){
			Clientes c = new Clientes();
			c.setNomeCliente(resultado.getString("c.nomeCliente"));
			
			PagamentosPendentes pp = new PagamentosPendentes();
			pp.setIdPagamento(resultado.getInt("pp.idPagamento"));
			pp.setVencimento1(resultado.getString("pp.vencimento1"));
			pp.setVencimento2(resultado.getString("pp.vencimento2"));
			pp.setClientes(c);
					
			lista.add(pp);
		}
		return lista;
	}
	
	public static void main(String[] args) {
		
		
		
	}

}

