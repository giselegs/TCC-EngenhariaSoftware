package br.com.academia.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import br.com.academia.domain.Clientes;
import br.com.academia.factory.ConexaoBD;

public class ClientesDAO {
	public void salvar(Clientes c) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO clientes");
		sql.append("(nomeCliente,");
		sql.append("rgCliente,");
		sql.append("cpfCliente,");
		sql.append("logradouroCliente,");
		sql.append("numeroCliente,");
		sql.append("bairroCliente,");
		sql.append("cidadeCliente,");
		sql.append("ufCliente,");
		sql.append("planoCliente,");
		sql.append("melhorDiaPagamentoCliente)");
		sql.append("VALUES (?,?,?,?,?,?,?,?,?,?)");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setString(1, c.getNomeCliente());
		comando.setString(2, c.getRgCliente());
		comando.setString(3, c.getCpfCliente());
		comando.setString(4, c.getLogradouroCliente());
		comando.setInt(5, c.getNumeroCliente());
		comando.setString(6, c.getBairroCliente());
		comando.setString(7, c.getCidadeCliente());
		comando.setString(8, c.getUfCliente());
		comando.setString(9, c.getPlanoCliente());
		comando.setInt(10, c.getMelhorDiaPagamento());
		comando.executeUpdate();	
	}
	
	public void excluir (Clientes c) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE FROM clientes  ");
		sql.append("WHERE idCliente = ? ");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setInt(1, c.getIdCliente());
		comando.executeUpdate();
	}
	
	public void editar (Clientes c) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("UPDATE clientes ");
		sql.append("SET logradouroCliente = ?, ");
		sql.append("numeroCliente = ?, ");
		sql.append("bairroCliente = ?, ");
		sql.append("cidadeCliente = ?, ");
		sql.append("ufCliente = ?, ");
		sql.append("planoCliente = ?, ");
		sql.append("melhorDiaPagamentoCliente = ? ");
		sql.append("WHERE idCliente = ?");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setString(1, c.getLogradouroCliente());
		comando.setInt(2, c.getNumeroCliente());
		comando.setString(3, c.getBairroCliente());
		comando.setString(4, c.getCidadeCliente());
		comando.setString(5, c.getUfCliente());
		comando.setString(6, c.getPlanoCliente());
		comando.setInt(7, c.getMelhorDiaPagamento());
		comando.setInt(8, c.getIdCliente());
		comando.executeUpdate();
	}
	
	public Clientes buscaPorCodigo(Clientes c) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM clientes ");
	    sql.append("WHERE idCliente = ?");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setInt(1, c.getIdCliente());
		
		ResultSet resultado = comando.executeQuery();
		
		Clientes retorno = null;
		
		if(resultado.next()){
			retorno = new Clientes();
			retorno.setIdCliente(resultado.getInt("idCliente"));
			retorno.setNomeCliente(resultado.getString("nomeCliente"));
			retorno.setRgCliente(resultado.getString("rgCliente"));
			retorno.setCpfCliente(resultado.getString("cpfCliente"));
			retorno.setLogradouroCliente(resultado.getString("logradouroCliente"));
			retorno.setNumeroCliente(resultado.getInt("numeroCliente"));
			retorno.setBairroCliente(resultado.getString("bairroCliente"));
			retorno.setCidadeCliente(resultado.getString("cidadeCliente"));
			retorno.setUfCliente(resultado.getString("ufCliente"));
			retorno.setPlanoCliente(resultado.getString("planoCliente"));
			retorno.setMelhorDiaPagamento(resultado.getInt("melhordiaPagamentoCliente"));
		}
		
		return retorno;
		
	}
	
	public ArrayList<Clientes> buscaPorNome(Clientes c) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM clientes ");
		sql.append("WHERE nomeCliente LIKE  ?");
		sql.append("ORDER BY nomeCliente ASC");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		
		comando.setString(1, "%" + c.getNomeCliente() + "%");
		
		ResultSet resultado = comando.executeQuery();
		
		ArrayList<Clientes> lista = new ArrayList<Clientes>();
		
		while(resultado.next()){
			Clientes item = new Clientes();
			item.setIdCliente(resultado.getInt("idCliente"));
			item.setNomeCliente(resultado.getString("nomeCliente"));
			item.setRgCliente(resultado.getString("rgCliente"));
			item.setCpfCliente(resultado.getString("cpfCliente"));
			item.setLogradouroCliente(resultado.getString("logradouroCliente"));
			item.setNumeroCliente(resultado.getInt("numeroCliente"));
			item.setBairroCliente(resultado.getString("bairroCliente"));
			item.setCidadeCliente(resultado.getString("cidadeCliente"));
			item.setUfCliente(resultado.getString("ufCliente"));
			item.setPlanoCliente(resultado.getString("planoCliente"));
			item.setMelhorDiaPagamento(resultado.getInt("melhorDiaPagamentoCliente"));
			
			lista.add(item);
		}
		return lista;
		
	}
	
	public ArrayList <Clientes> listar() throws SQLException, ClassNotFoundException {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM clientes ");
	    sql.append("ORDER BY nomeCliente ASC");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		
		
		ResultSet resultado = comando.executeQuery();
		
		ArrayList<Clientes> lista = new ArrayList<Clientes>();
		
		while(resultado.next()){
			Clientes c = new Clientes();
			c.setIdCliente(resultado.getInt("idCliente"));
			c.setNomeCliente(resultado.getString("nomeCliente"));
			c.setRgCliente(resultado.getString("rgCliente"));
			c.setCpfCliente(resultado.getString("cpfCliente"));
			c.setLogradouroCliente(resultado.getString("logradouroCliente"));
			c.setNumeroCliente(resultado.getInt("numeroCliente"));
			c.setBairroCliente(resultado.getString("bairroCliente"));
			c.setCidadeCliente(resultado.getString("cidadeCliente"));
			c.setUfCliente(resultado.getString("ufCliente"));
			c.setPlanoCliente(resultado.getString("planoCliente"));
			c.setMelhorDiaPagamento(resultado.getInt("melhorDiaPagamentoCliente"));
			
			lista.add(c);
		}
		return lista;
	}
	
	public static void main(String[] args) {
		
		
		Clientes c1 = new Clientes();
		c1.setNomeCliente("Isabela Pietra Luzia Lopes");
		c1.setRgCliente("115511015");
		c1.setCpfCliente("87384079578");
		c1.setLogradouroCliente("Avenida Poeta Castro Alves");
		c1.setNumeroCliente(694);
		c1.setBairroCliente("Fonte Nova");
		c1.setCidadeCliente("Santana");
		c1.setUfCliente("AP");
		c1.setPlanoCliente("Anual");
		c1.setMelhorDiaPagamento(20);
		
		Clientes c2 = new Clientes();
		c2.setNomeCliente("Benjamin Tom�s Assun��o");
		c2.setRgCliente("158054544");
		c2.setCpfCliente("20852183348");
		c2.setLogradouroCliente("Rua Padre Alzir Sampaio");
		c2.setNumeroCliente(368);
		c2.setBairroCliente("Presidente Kennedy");
		c2.setCidadeCliente("Fortaleza");
		c2.setUfCliente("CE");
		c2.setPlanoCliente("Mensal");
		c2.setMelhorDiaPagamento(5);
		
		Clientes c3 = new Clientes();
		c3.setNomeCliente("Henry Benjamin Lima");
		c3.setRgCliente("173555147");
		c3.setCpfCliente("22987384327");
		c3.setLogradouroCliente("Rua Rep�blica Centro Africana");
		c3.setNumeroCliente(698);
		c3.setBairroCliente("Pau Amarelo");
		c3.setCidadeCliente("Paulista");
		c3.setUfCliente("PE");
		c3.setPlanoCliente("Mensal");
		c3.setMelhorDiaPagamento(20);
		
		Clientes c4 = new Clientes();
		c4.setNomeCliente("Cl�udio Ben�cio Cardoso");
		c4.setRgCliente("261148539");
		c4.setCpfCliente("44986160575");
		c4.setLogradouroCliente("Quadra SQS 105 Bloco D");
		c4.setNumeroCliente(523);
		c4.setBairroCliente("Asa Sul");
		c4.setCidadeCliente("Bras�lia");
		c4.setUfCliente("DF");
		c4.setPlanoCliente("Mensal");
		c4.setMelhorDiaPagamento(5);
		
		Clientes c5 = new Clientes();
		c5.setNomeCliente("Marcela Esther Teresinha Viana");
		c5.setRgCliente("365036547");
		c5.setCpfCliente("36086656681");
		c5.setLogradouroCliente("Rua das Ind�strias");
		c5.setNumeroCliente(595);
		c5.setBairroCliente("Setor Morais");
		c5.setCidadeCliente("Goi�nia");
		c5.setUfCliente("GO");
		c5.setPlanoCliente("Anual");
		c5.setMelhorDiaPagamento(20);
		
		Clientes c6 = new Clientes();
		c6.setNomeCliente("Laura Rebeca Lima");
		c6.setRgCliente("264880717");
		c6.setCpfCliente("90110804830");
		c6.setLogradouroCliente("Travessa Tito Franco");
		c6.setNumeroCliente(636);
		c6.setBairroCliente("Bras�lia");
		c6.setCidadeCliente("Bel�m");
		c6.setUfCliente("PA");
		c6.setPlanoCliente("Anual");
		c6.setMelhorDiaPagamento(5);
		
		Clientes c7 = new Clientes();
		c7.setNomeCliente("Augusto Manuel Osvaldo Foga�a");
		c7.setRgCliente("167970604");
		c7.setCpfCliente("68068391428");
		c7.setLogradouroCliente("Rua Posto de Sa�de");
		c7.setNumeroCliente(886);
		c7.setBairroCliente("886");
		c7.setCidadeCliente("Ema");
		c7.setUfCliente("CE");
		c7.setPlanoCliente("Mensal");
		c7.setMelhorDiaPagamento(20);
		
		Clientes c8 = new Clientes();
		c8.setNomeCliente("Vicente Antonio Jo�o Fernandes");
		c8.setRgCliente("126934186");
		c8.setCpfCliente("37790865730");
		c8.setLogradouroCliente("Rua Jacinta Cocculo Piazza");
		c8.setNumeroCliente(739);
		c8.setBairroCliente("Nossa Senhora da Salete");
		c8.setCidadeCliente("Crici�ma");
		c8.setUfCliente("SC");
		c8.setPlanoCliente("Anual");
		c8.setMelhorDiaPagamento(5);
		
		Clientes c9 = new Clientes();
		c9.setNomeCliente("Gabrielly Luiza Mariah Ribeiro");
		c9.setRgCliente("154189856");
		c9.setCpfCliente("61958455822");
		c9.setLogradouroCliente("Rua Bruno Luiz Romeiro de Aguiar");
		c9.setNumeroCliente(382);
		c9.setBairroCliente("Pedra Branca");
		c9.setCidadeCliente("Ribeir�o das Neves");
		c9.setUfCliente("MG");
		c9.setPlanoCliente("Anual");
		c9.setMelhorDiaPagamento(20);
		
		Clientes c10 = new Clientes();
		c10.setNomeCliente("Iago Marcelo Thiago Melo");
		c10.setRgCliente("387850648");
		c10.setCpfCliente("07240605612");
		c10.setLogradouroCliente("Beco Rio Machado");
		c10.setNumeroCliente(661);
		c10.setBairroCliente("Tri�ngulo");
		c10.setCidadeCliente("Porto Velho");
		c10.setUfCliente("RO");
		c10.setPlanoCliente("Mensal");
		c10.setMelhorDiaPagamento(5);
		
		ClientesDAO cdao = new ClientesDAO();
		try {
			cdao.salvar(c1);
			cdao.salvar(c2);
			cdao.salvar(c3);
			cdao.salvar(c4);
			cdao.salvar(c5);
			cdao.salvar(c6);
			cdao.salvar(c7);
			cdao.salvar(c8);
			cdao.salvar(c9);
			cdao.salvar(c10);
			System.out.println("Salvo com sucesso!");
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao salvar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao salvar 2!");
			e.printStackTrace();
		}
		
		
		/*Clientes c1 = new Clientes();
		c1.setIdCliente(2);
		
		ClientesDAO cdao = new ClientesDAO();
		try {
			cdao.excluir(c1);
			System.out.println("Deletado com sucesso!");
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao deletar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao deletar 2!");
			e.printStackTrace();
		}*/
		
		/*Clientes c1 = new Clientes();
		c1.setIdCliente(3);
		c1.setLogradouroCliente("Rua das Estrelas");
		c1.setNumeroCliente(121);
		c1.setBairroCliente("Raiar");
		c1.setCidadeCliente("Boa Vista");
		c1.setUfCliente("RR");
		c1.setPlanoCliente("Mensal");
		c1.setMelhorDiaPagamento(15);
		
		
		ClientesDAO cdao = new ClientesDAO();
		try {
			cdao.editar(c1);
			System.out.println("Editado com sucesso!");
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao editar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao editar 2!");
			e.printStackTrace();
		}*/
		
		/*Clientes c2 = new Clientes();
		c2.setIdCliente(4);
		
		ClientesDAO cdao = new ClientesDAO();
		try {
			//cdao.salvar(c1);
			Clientes cli = cdao.buscaPorCodigo(c2);
			System.out.println("Resultado:" +cli);
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao buscar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao buscar 2!");
			e.printStackTrace();
		}*/
		
		/*ClientesDAO cdao = new ClientesDAO();
		try {
			ArrayList <Clientes> lista = cdao.listar();
			
			for(Clientes c : lista){
				System.out.println("Clientes:" +c);
			}
			
			
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao buscar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao buscar 2!");
			e.printStackTrace();
		}*/
		
		
		/*Clientes c1 = new Clientes();
		c1.setNomeCliente("Clara");
		
		ClientesDAO cdao = new ClientesDAO();
		
		try {
			ArrayList <Clientes> lista = cdao.buscaPorNome(c1);
			
			for(Clientes c : lista){
				System.out.println("Clientes:" +c);
			}
			
			
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao buscar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao buscar 2!");
			e.printStackTrace();
		}*/
		
	}

}
