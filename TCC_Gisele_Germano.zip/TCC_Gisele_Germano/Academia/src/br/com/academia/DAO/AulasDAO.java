package br.com.academia.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.academia.domain.Aulas;
import br.com.academia.domain.Instrutores;
import br.com.academia.factory.ConexaoBD;

public class AulasDAO {
	public void salvar(Aulas a) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO aulas");
		sql.append("(nomeAula,");
		sql.append("horarioInicio,");
		sql.append("horarioFim,");
		sql.append("sala,");
		sql.append("diasSemana,");
		sql.append("fk_instrutor)");
		sql.append("VALUES (?,?,?,?,?,?)");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setString(1, a.getNomeAula());
		comando.setString(2, a.getHorarioInicio());
		comando.setString(3, a.getHorarioFim());
		comando.setString(4, a.getSala());
		comando.setString(5, a.getDiasSemana());
		comando.setInt(6, a.getInstrutores().getIdInstrutor());
		comando.executeUpdate();	
			
	}
	
	public void excluir (Aulas a) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("DELETE FROM aulas  ");
		sql.append("WHERE idAula = ? ");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setInt(1, a.getIdAula());
		comando.executeUpdate();
	}
	
	public void editar (Aulas a) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("UPDATE aulas ");
		sql.append("SET horarioInicio = ?, ");
		sql.append("horarioFim = ?, ");
		sql.append("sala = ?, ");
		sql.append("diasSemana = ? ");
		//sql.append("fk_instrutor = ?");
		sql.append("WHERE idAula = ?");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setString(1, a.getHorarioInicio());
		comando.setString(2, a.getHorarioFim());
		comando.setString(3, a.getSala());
		comando.setString(4, a.getDiasSemana());
		comando.setInt(5, a.getIdAula());
		
		comando.executeUpdate();
	}
	
	public Aulas buscaPorCodigo(Aulas a) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM aulas ");
	    sql.append("WHERE idAula = ?");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		comando.setInt(1, a.getIdAula());
		
		ResultSet resultado = comando.executeQuery();
		
		Aulas retorno = null;
		
		if(resultado.next()){
			retorno = new Aulas();
			retorno.setIdAula(resultado.getInt("idAula"));
			retorno.setNomeAula(resultado.getString("nomeAula"));
			retorno.setHorarioInicio(resultado.getString("horarioInicio"));
			retorno.setHorarioFim(resultado.getString("horarioFim"));
			retorno.setSala(resultado.getString("sala"));
			retorno.setDiasSemana(resultado.getString("diasSemana"));
			//retorno.setInstrutores(instrutores);
			
		}
		
		return retorno;
		
	}
	
	public ArrayList<Aulas> buscaPorNome(Aulas a) throws SQLException, ClassNotFoundException{
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT * ");
		sql.append("FROM aulas ");
		sql.append("WHERE nomeAula LIKE  ?");
		sql.append("ORDER BY nomeAula ASC");
		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		
		comando.setString(1, "%" + a.getNomeAula() + "%");
		
		ResultSet resultado = comando.executeQuery();
		
		ArrayList<Aulas> lista = new ArrayList<Aulas>();
		
		while(resultado.next()){
			Aulas item = new Aulas();
			item.setIdAula(resultado.getInt("idAula"));
			item.setNomeAula(resultado.getString("nomeAula"));
			item.setHorarioInicio(resultado.getString("horaInicio"));
			item.setHorarioFim(resultado.getString("horaFim"));
			item.setSala(resultado.getString("sala"));
			item.setDiasSemana(resultado.getString("diasSemana"));
						
			lista.add(item);
		}
		return lista;
		
	}
	
	public ArrayList <Aulas> listar() throws SQLException, ClassNotFoundException {
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT a.idAula, ");
		sql.append("a.nomeAula, ");
		sql.append("a.horarioInicio, ");
		sql.append("a.horarioFim, ");
		sql.append("a.sala, ");
		sql.append("a.diasSemana, ");
		sql.append("a.fk_instrutor, ");
		sql.append("i.nomeInstrutor ");
		sql.append("FROM aulas a ");
	    sql.append("INNER JOIN instrutores i on i.idInstrutor = a.fk_instrutor ");
	    		
		Connection conexao = ConexaoBD.conectar();
		
		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		
		
		ResultSet resultado = comando.executeQuery();
		
		ArrayList<Aulas> lista = new ArrayList<Aulas>();
		
		while(resultado.next()){
			Instrutores i = new Instrutores();
			i.setNomeInstrutor(resultado.getString("i.nomeInstrutor"));
			
			Aulas a = new Aulas();
			a.setIdAula(resultado.getInt("a.idAula"));
			a.setNomeAula(resultado.getString("a.nomeAula"));
			a.setHorarioInicio(resultado.getString("a.horarioInicio"));
			a.setHorarioFim(resultado.getString("a.horarioFim"));
			a.setSala(resultado.getString("a.sala"));
			a.setDiasSemana(resultado.getString("a.diasSemana"));
			a.setInstrutores(i);
					
			lista.add(a);
		}
		return lista;
	}
	
	public static void main(String[] args) {
		/*Instrutores i1 = new Instrutores();
		Instrutores i2 = new Instrutores();
		
		Aulas a1 = new Aulas();
		a1.setNomeAula("Zumba");
		a1.setHorarioInicio("10:20");
		a1.setHorarioFim("11:00");
		a1.setSala("2");
		a1.setDiasSemana("Segunda-feira");
		//a1.setInstrutores(i1.setIdInstrutor(1););

		Aulas a2 = new Aulas();
		a2.setNomeAula("Circuito Funcional");
		a2.setHorarioInicio("18:00");
		a2.setHorarioFim("18:40");
		a2.setSala("1");
		a2.setDiasSemana("Quarta-feira");
		//a2.setInstrutores(i2);
		
		
		
		AulasDAO adao = new AulasDAO();
		try {
			adao.salvar(a1);
			adao.salvar(a2);
			System.out.println("Salvo com sucesso!");
		} catch (ClassNotFoundException e) {
			System.out.println("Erro ao salvar 1!");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("Erro ao salvar 2!");
			e.printStackTrace();
		}*/
		
	}

}

